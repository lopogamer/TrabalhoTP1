#include "Dominios.h"
#include "Entidade.h"
#include <iostream>
#include <locale>
using namespace std;

int main() {
    setlocale(LC_ALL, "portuguese");
    return 0;
}
