#include "Entidade.h"
using namespace std;

int main(){


}
