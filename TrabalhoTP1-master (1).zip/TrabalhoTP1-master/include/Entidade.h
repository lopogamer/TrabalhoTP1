#ifndef ENTIDADE_H_INCLUDED
#define ENTIDADE_H_INCLUDED

class Atividade{
private:
    Codigo


};

#endif // ENTIDADE_H_INCLUDED
